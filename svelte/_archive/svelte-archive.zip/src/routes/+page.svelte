<h1>Test Svelte App</h1>
<p>Welcome to the tiny login + instructor/student test site.</p>