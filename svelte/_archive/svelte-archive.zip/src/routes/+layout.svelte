<nav style="display:flex; gap:1rem;">
  <a href="/">Home</a>
  <a href="/login">Login</a>
  <a href="/instructor">Instructor</a>
  <a href="/student">Student</a>
</nav>
<slot />