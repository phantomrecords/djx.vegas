<h2>Login</h2>
<form method="POST">
  <input name="email" placeholder="Email" required>
  <input name="password" type="password" placeholder="Password" required>
  <button>Login</button>
</form>